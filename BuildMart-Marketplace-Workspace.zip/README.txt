BUILDMART MARKETPLACE WORKSPACE — FRONTEND PROTOTYPE

PACKAGE CONTENTS
- index.html: role-based marketplace workspace with Customer/Buyer, Material Supplier/Owner, Truck Owner/Transporter, Contractor/Builder and Platform Admin views.

INCLUDED MODULES
Customer: material discovery, radius filter UI, supplier comparison entry point, requirements, quotes, orders/delivery, saved suppliers, budget, generic volume calculator, site diary, reviews/disputes, profile/addresses.
Supplier: business profile, inventory/listings, add material, leads, quote workflow, fulfilment, delivery, invoices/payments, analytics, promotions, staff permissions.
Transporter: fleet/vehicles, drivers, available trips, delivery requests, trip cost calculator, documents, earnings, analytics.
Contractor: projects, material planner, bulk requirements, supplier shortlist, purchase orders, site deliveries, team/labour, budget, progress, documents.
Admin: user management, supplier verification, category/listing moderation, leads, orders/disputes, transport network, payments/commission, locations, reports, settings.

INSTALL ON GITHUB PAGES
1. Download and extract this ZIP.
2. In your construction-materials-marketplace repository, upload the index.html from this ZIP to the repository ROOT.
3. Replace the old index.html and commit to main.
4. Wait for GitHub Pages deployment and refresh your website.

IMPORTANT PRODUCT STATUS
This is a substantial front-end product prototype, not yet a production marketplace. It contains sample UI and session-only demo interactions. It does NOT yet have real accounts, database persistence, live supplier inventory/prices, geolocation, real quote messaging, booking/order execution, truck dispatch, payments, GST invoices, notifications, document storage, admin enforcement or secure role permissions. Those require a backend (for example Supabase with database policies and secure server-side functions), authentication, storage, APIs, testing and deployment configuration. Do not collect real customer data or launch payments using this prototype. Do not put private keys/passwords in the public GitHub repository.

Suggested production build sequence:
1. Database schema + authentication + role permissions.
2. Supplier onboarding/KYC and admin approval.
3. Material catalogue, units, stock, pricing and service-area coordinates.
4. Buyer RFQ, quote negotiation and supplier messaging.
5. Contractor project procurement and purchase orders.
6. Transporter fleet, trip matching, dispatch and delivery proof.
7. Orders, invoices, payment gateway, refunds and dispute workflows.
8. Notifications, analytics, audit logs, security and privacy compliance.
